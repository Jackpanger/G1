a = ['age', 'bp', 'sg', 'al', 'su', 'rbc', 'pc', 'pcc', 'ba', 'bgr', 'bu', 'sc', 'sod', 'pot', 'hemo', 'pcv', 'wc', 'rc', 'htn', 'dm', 'cad', 'appet', 'pe', 'ane']
for i in a:
    print(f'''<li>
					<label for="{i}">{i}:</label>
					<input type="text" id="{i}" class='t' name="{i}" />
				</li>''')