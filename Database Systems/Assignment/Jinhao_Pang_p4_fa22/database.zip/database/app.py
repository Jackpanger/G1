from flask import Flask, render_template, request
from markupsafe import escape

app = Flask(__name__)


@app.route('/')
def model():  # put application's code here
    return render_template('index.html')


@app.route('/result', methods=['POST', 'GET'])
def result():  # put application's code here
    if request.method == 'POST':
        data = []
        for i in request.form.values():
            if i == 'normal' or i == 'notpresent' or i == 'no' or i == 'good':
                data.append(1)
            elif i == 'abnormal' or i == 'present' or i == 'yes' or i == 'poor':
                data.append(2)
            elif i == 'none':
                data.append(0)
            else:
                data.append(i)
        print(data)
        import pickle, pandas as pd, numpy as np
        pkl_filename = "model.pkl"
        column = ['age', 'bp', 'sg', 'al', 'su', 'rbc', 'pc', 'pcc', 'ba', 'bgr', 'bu', 'sc', 'sod',
                  'pot', 'hemo', 'pcv', 'wc', 'rc', 'htn', 'dm', 'cad', 'appet', 'pe', 'ane']
        df = pd.DataFrame(np.array(data).reshape(1, -1), columns=column)
        with open(pkl_filename, 'rb') as file:
            pickle_model = pickle.load(file)
        score = pickle_model.predict(df)
    print(score[0])
    return render_template('result.html', result=score[0])


if __name__ == '__main__':
    app.run()
